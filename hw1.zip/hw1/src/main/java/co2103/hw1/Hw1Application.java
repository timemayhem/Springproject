package co2103.hw1;

import co2103.hw1.domain.Cafe;
import co2103.hw1.domain.Cake;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class Hw1Application {

    public static List<Cake> cakesList = new ArrayList<>();
    public static List<Cafe> cafesList = new ArrayList<>();

    public static void main(String[] args)
    {
        SpringApplication.run(Hw1Application.class, args);
        Cake cake1 = new Cake("cake1","cake1","ingredients1",1);
        Cake cake2 = new Cake("cake2","cake2","ingredients2",1);

        cakesList.add(cake1);


        Cafe cafe1 = new Cafe(1,"cafe1","LE1 C1",cakesList);

        cafesList.add(cafe1);
    }

}