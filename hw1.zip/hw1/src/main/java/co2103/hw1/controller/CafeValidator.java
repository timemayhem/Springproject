package co2103.hw1.controller;

import co2103.hw1.Hw1Application;
import co2103.hw1.domain.Cafe;
import co2103.hw1.domain.Cake;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


public class CafeValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz)
    {
        return Cafe.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors)
    {
        Cafe a = (Cafe) target;
        for(Cafe ex : Hw1Application.cafesList)
        {
            if (ex.getId() == a.getId())
            {
                errors.rejectValue("id","","ID already exists");
            }
        }
        //checking name
        ValidationUtils.rejectIfEmptyOrWhitespace(errors,"name","","Your Cafe needs a name");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors,"address","","Your Cafe needs an address");
    }
}
