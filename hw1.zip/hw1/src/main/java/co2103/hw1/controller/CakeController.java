package co2103.hw1.controller;

import co2103.hw1.Hw1Application;
import co2103.hw1.domain.Cafe;
import co2103.hw1.domain.Cake;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
    public class CakeController {

    @InitBinder
    protected void initBinder(WebDataBinder binder){
        binder.addValidators(new CakeValidator());
    }

        @GetMapping("/cakes")
        public String getCakes(Model model, @RequestParam Cake cake)
    {
        List<Cake> cakeList = Hw1Application.cakesList;
        model.addAttribute("cakes", cakeList);
        return "cakes/list";
    }

    @RequestMapping(value="/newCake")
    public String newCake(Model model, @RequestParam Cafe cafe)
    {
        model.addAttribute("cake",new Cake());
        return "cakes/form";
    }

    @RequestMapping(value = "/addCake", method = RequestMethod.POST)
    public String addCafe(@ModelAttribute Cake cake, @RequestParam Cafe cafe)
    {
        Hw1Application.cakesList.add(cake);
        return "redirect:/cafes";
    }
}
