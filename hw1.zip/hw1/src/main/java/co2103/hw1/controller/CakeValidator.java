package co2103.hw1.controller;

import co2103.hw1.Hw1Application;
import co2103.hw1.domain.Cafe;
import co2103.hw1.domain.Cake;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class CakeValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return Cake.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        Cake a = (Cake) target;


        //checking name
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "", "Your Cake needs a name");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description", "", "Your Cake needs a description");

        if (!("Sugar".equals(a.getIngredients())) || !("Butter".equals(a.getIngredients())) || !("Flour".equals(a.getIngredients()))) {
            errors.rejectValue("ingredients", "", "incorrect ingredients");
        }

        if (!(a.getAmount() >= 0) || !(a.getAmount() < 16)) {
            errors.rejectValue("amount","","invalid amount");
        }
    }
}

