package co2103.hw1.domain;

import java.util.List;

public class Cafe {
    private int id;
    private String name;
    private String address;
    private List<Cake> cakes;

    public Cafe() {
        this.setId(0);
        this.setName("placeholder");
        this.setAddress("placeholder");
        this.setCakes(cakes);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<Cake> getCakes() {
        return cakes;
    }

    public void setCakes(List<Cake> cakes) {
        this.cakes = cakes;
    }


    public Cafe(int id, String name, String address, List cakes)
    {
        this.setId(id);
        this.setName(name);
        this.setAddress(address);
        this.setCakes(cakes);

    }
}
