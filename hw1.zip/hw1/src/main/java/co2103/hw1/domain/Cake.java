package co2103.hw1.domain;
public class Cake {
    private String name;
    private String description;
    private String ingredients;
    private int amount;

    public Cake(String name,String description,String ingredients,int amount){

        this.setName(name);
        this.setDescription(description);
        this.setIngredients(ingredients);
        this.setAmount(amount);

    }

    public Cake() {
        this.setName("placeholder");
        this.setDescription("description");
        this.setIngredients("ingredients");
        this.setAmount(amount);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIngredients() {
        return ingredients;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }


}



